"""
Стратегії збурень для інверсійної регуляризації.
"""
from abc import ABC, abstractmethod

import torch


class PerturbationStrategy(ABC):
    """
    Абстрактний базовий клас для стратегій збурень.
    """

    @abstractmethod
    def apply(self, x: torch.Tensor) -> torch.Tensor:
        """
        Застосувати збурення до вхідного тензору.

        Args:
            x (torch.Tensor): Вхідний тензор

        Returns:
            torch.Tensor: Збурений тензор
        """
        pass


class GaussianNoisePerturbation(PerturbationStrategy):
    """
    Додає Gaussian noise до вхідних даних: X' = X + ε, де ε ~ N(0, σ²).

    Args:
        std (float): Стандартне відхилення Gaussian noise (default: 0.01)
    """

    def __init__(self, std: float = 0.01):
        self.std = std

    def apply(self, x: torch.Tensor) -> torch.Tensor:
        """
        Додає Gaussian noise до вхідного тензору.

        Args:
            x (torch.Tensor): Вхідний тензор

        Returns:
            torch.Tensor: Збурений тензор X + N(0, σ²)
        """
        noise = torch.randn_like(x) * self.std
        return x + noise


class TimeStepDropoutPerturbation(PerturbationStrategy):
    """
    Випадково обнуляє часові кроки у послідовності.

    Args:
        drop_prob (float): Ймовірність обнулення часового кроку (default: 0.1)
    """

    def __init__(self, drop_prob: float = 0.1):
        self.drop_prob = drop_prob

    def apply(self, x: torch.Tensor) -> torch.Tensor:
        """
        Застосовує dropout до часових кроків.

        Args:
            x (torch.Tensor): Вхідний тензор розміру (batch_size, seq_len, input_dim)

        Returns:
            torch.Tensor: Збурений тензор з обнуленими часовими кроками
        """
        if self.training:
            # Створити маску для часових кроків
            mask = torch.rand(x.size(0), x.size(1), 1, device=x.device) > self.drop_prob
            return x * mask.float()
        return x


def get_perturbation(mode: str, **kwargs) -> PerturbationStrategy:
    """
    Фабрична функція для створення стратегії збурень.

    Args:
        mode (str): Тип збурення ('gaussian', 'timestep_dropout')
        **kwargs: Додаткові параметри для стратегії

    Returns:
        PerturbationStrategy: Екземпляр стратегії збурень

    Raises:
        ValueError: Якщо mode не підтримується
    """
    if mode == "gaussian":
        return GaussianNoisePerturbation(std=kwargs.get("std", 0.01))
    elif mode == "timestep_dropout":
        return TimeStepDropoutPerturbation(drop_prob=kwargs.get("drop_prob", 0.1))
    else:
        raise ValueError(
            f"Непідтримуваний режим збурень: {mode}. " f"Доступні: 'gaussian', 'timestep_dropout'"
        )
